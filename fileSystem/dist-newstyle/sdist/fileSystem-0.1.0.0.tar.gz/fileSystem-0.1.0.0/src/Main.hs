module Main (main) where

import IO (startSystem)

main :: IO ()
main = startSystem